package com.bignerdranch.android.pract1

import android.content.Context
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.app.AlertDialog
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView

class MainActivity2 : AppCompatActivity() {
    lateinit var spinner:Spinner
    lateinit var kolvo:EditText
    lateinit var resvivod: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)
        spinner = findViewById(R.id.spinn)
        kolvo = findViewById(R.id.kolvometrov)
        resvivod = findViewById(R.id.vivod)
    }
    fun nazad(view: View) {
        val intent = Intent(this,MainActivity::class.java)
        startActivity(intent)
    }
    fun nextscreen(view: View) {

        val meters = kolvo.text.toString().toIntOrNull()

        if (meters != null && meters > 5) {
            val spin = spinner.selectedItemPosition
            var stoimostkvmetr = 105140
            var result = 0.0

            when (spin) {
                0 -> result = stoimostkvmetr * meters * 1.4
                1 -> result = stoimostkvmetr * meters.toDouble()
                2 -> result = stoimostkvmetr * meters * 0.8
                3 -> result = stoimostkvmetr * meters * 1.1
            }
            val formattedResult = String.format("%.2f", result / 1000) + " тыс. рублей"
            resvivod.text = formattedResult

            val intent = Intent(this, MainActivity3::class.java)
            intent.putExtra("kolvometr", meters)
            intent.putExtra("result", formattedResult)
            startActivity(intent)

        } else {
            AlertDialog.Builder(this)
                .setTitle("Ошибка")
                .setMessage("Введите количество метров заново!")
                .setPositiveButton("OK", null)
                .create()
                .show()
        }
    }
    }
